const $=id=>document.getElementById(id);
const messages=$("messages"), history=[];
let listening=false, recognition=null, busy=false;
function setStatus(s){$("callStatus").textContent=s;}
function addMessage(text,role){
 const article=document.createElement("article");article.className="bubble "+(role==="assistant"?"assistant":"user");
 const who=document.createElement("b");who.textContent=role==="assistant"?"Aira":"You";
 const p=document.createElement("p");p.textContent=text;article.append(who,p);messages.append(article);
 $("count").textContent=messages.children.length+" messages";messages.scrollTop=messages.scrollHeight;
}
function selectedLang(){return $("language").value;}
function speechLocale(){
 const v=selectedLang();
 if(v==="Telugu")return "te-IN";if(v==="Hindi")return "hi-IN";if(v==="English")return "en-IN";
 return "te-IN"; // Auto mode defaults to Telugu recognition; choose English/Hindi manually when needed.
}
function speak(text){
 if(!("speechSynthesis" in window)){setStatus("Text reply ready. This browser has no speech output.");return;}
 speechSynthesis.cancel();
 const utter=new SpeechSynthesisUtterance(text), v=selectedLang();
 utter.lang=v==="Telugu"?"te-IN":v==="Hindi"?"hi-IN":"en-IN";
 const voices=speechSynthesis.getVoices();
 if($("voiceMode").value==="female"){
   const preferred=voices.find(x=>/female|woman|zira|heera|samantha|google.*(telugu|hindi|english)/i.test(x.name+" "+x.lang) && (x.lang.toLowerCase().startsWith(utter.lang.slice(0,2))));
   if(preferred)utter.voice=preferred;
 }
 utter.rate=0.96;
 utter.onstart=()=>{$("stage")?.classList.add("speaking");document.querySelector(".stage").classList.add("speaking");setStatus("Aira is speaking…");};
 utter.onend=()=>{document.querySelector(".stage").classList.remove("speaking");setStatus("Your turn — tap Talk");};
 utter.onerror=()=>{document.querySelector(".stage").classList.remove("speaking");setStatus("Voice playback unavailable; read the reply below.");};
 speechSynthesis.speak(utter);
}
async function send(text){
 text=(text||"").trim();if(!text||busy)return;
 busy=true;addMessage(text,"user");history.push({role:"user",text});$("message").value="";setStatus("Aira is thinking…");
 try{
  const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text,language:selectedLang(),history:history.slice(-13,-1)})});
  const d=await r.json();if(!r.ok)throw new Error(d.error||"AI connection failed");
  addMessage(d.answer,"assistant");history.push({role:"assistant",text:d.answer});speak(d.answer);
 }catch(e){addMessage("Setup: "+e.message,"assistant");setStatus("AI setup needed or service temporarily unavailable.");}
 finally{busy=false;}
}
$("sendBtn").addEventListener("click",()=>send($("message").value));
$("message").addEventListener("keydown",e=>{if(e.key==="Enter")send($("message").value);});
$("stopBtn").addEventListener("click",()=>{if(recognition)recognition.stop();if("speechSynthesis"in window)speechSynthesis.cancel();document.querySelector(".stage").classList.remove("speaking");setStatus("Stopped");});
$("clearBtn").addEventListener("click",()=>{history.length=0;messages.replaceChildren();$("count").textContent="0 messages";setStatus("New conversation started");});
const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
$("talkBtn").addEventListener("click",()=>{
 if(!SpeechRecognition){setStatus("Voice input not supported. Open this installed app in Chrome on Android.");return;}
 if(listening&&recognition){recognition.stop();return;}
 recognition=new SpeechRecognition();recognition.lang=speechLocale();recognition.interimResults=false;recognition.maxAlternatives=1;
 recognition.onstart=()=>{listening=true;setStatus("Listening… speak now");};
 recognition.onresult=e=>send(e.results[0][0].transcript);
 recognition.onerror=e=>setStatus("Microphone error: "+e.error+". Check browser permission.");
 recognition.onend=()=>{listening=false;if(!busy)setStatus("Tap Talk to speak again");};
 recognition.start();
});
async function health(){try{const r=await fetch("/api/health");const d=await r.json();$("connection").textContent=d.aiConfigured?"AI connected":"Setup required";}catch{$("connection").textContent="Offline";}}
health();
if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));