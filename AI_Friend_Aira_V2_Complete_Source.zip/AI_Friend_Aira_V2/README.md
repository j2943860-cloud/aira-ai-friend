# AI Friend – Aira V2

This is an upgraded Android-installable PWA source project. It is not yet a signed APK or a Play Store listing.

## V2 features
- Updated video-call-style interface
- Generated fictional female AI portrait
- Microphone speech input using browser SpeechRecognition
- Spoken replies using device/browser text-to-speech
- Telugu, English and Hindi language selector
- Conversation history for the current session
- Stop speech, clear chat, health status
- Server-side Gemini API proxy; API key is not exposed to browser code
- PWA manifest and service worker for home-screen installation

## Honest limitations
- The displayed face is a still generated portrait with a speaking status animation. It is NOT real-time generated video, live facial motion, or lip-synced animation.
- Voice recognition is browser/device-dependent. Auto mode defaults to Telugu recognition; manually select English or Hindi when needed.
- The selected speech voice is only a preference; Android may not have a female voice for every language.
- AI responses require internet and a Gemini API key. Google AI Studio may provide a free tier, but availability, quotas, supported models and terms can change. Unlimited free usage is not guaranteed.
- This project has no subscription/payment feature, but hosting and AI usage can incur costs.
- The companion is fictional and clearly identified as AI.

## Run locally
1. Install Node.js 20 or newer.
2. Extract the ZIP and open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Create an API key at https://aistudio.google.com/apikey and set `GEMINI_API_KEY` in `.env`.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Install on Android
The app must be served from HTTPS for reliable microphone/PWA installation:
1. Deploy this Node project to a Node-compatible HTTPS host.
2. Add `GEMINI_API_KEY` as a private environment variable on the host. Do not commit `.env`.
3. Open the HTTPS URL in Chrome on Android.
4. Tap Chrome menu ⋮ → Install app / Add to Home screen.
5. Grant microphone permission when tapping Talk.

## Create a Play Store APK
This ZIP is not an APK. Publishing requires Android packaging (for example, a Trusted Web Activity), a signing key, app icons, screenshots, privacy policy, and Play Console review. Do not upload API keys in the APK. Keep the API key on the server.

## Privacy
Speech recognition may send audio to the browser/device speech provider. Text messages are sent to the configured Gemini API. Avoid sharing passwords, financial details, or other sensitive information. Microphone access starts only after the user taps Talk.