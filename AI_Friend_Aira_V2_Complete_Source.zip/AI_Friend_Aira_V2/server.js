require("dotenv").config();
const express = require("express");
const path = require("path");
const app = express();

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "put_your_key_here") });
});

app.post("/api/chat", async (req, res) => {
  try {
    const key = process.env.GEMINI_API_KEY;
    if (!key || key === "put_your_key_here") {
      return res.status(503).json({ error: "AI is not connected yet. Add your Gemini API key to the server .env file." });
    }
    const { message, language = "Auto", history = [] } = req.body || {};
    if (typeof message !== "string" || !message.trim()) return res.status(400).json({ error: "Please enter a message." });

    const system = `You are Aira, a friendly fictional female AI companion. You are not a human and must never claim to be one. The user's preferred language is ${language}. Reply in the language the user used, choosing Telugu, English, or Hindi as appropriate. Be warm, natural, concise, and suitable for spoken conversation. Do not use markdown tables.`;
    const contents = history.slice(-12).map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: String(m.text || "").slice(0, 2500) }]
    }));
    contents.push({ role: "user", parts: [{ text: system + "\n\nUser: " + message.trim().slice(0, 4000) }] });

    const upstream = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(key),
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents, generationConfig: { temperature: 0.75, maxOutputTokens: 600 } })
      }
    );
    const data = await upstream.json();
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.error?.message || "AI provider error or usage limit reached." });
    const answer = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
    if (!answer) return res.status(502).json({ error: "The AI returned no text. Please try again." });
    res.json({ answer });
  } catch (err) {
    res.status(500).json({ error: "Server error. Check the connection and try again." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Aira V2 listening on port ${port}`));